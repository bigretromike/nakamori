First go download PyCharm (IntelliJ IDEA does not have the remote python debugger): https://www.jetbrains.com/pycharm/download/#section=windows
Then copy everything inside pydevd folder into C:\Program Files (x86)\Kodi\system\python\Lib
Open nakamori in PyCharm.
Go to build configurations.
Add a new Remote Python Debugger.
Enter the IP of the Kodi install (localhost is fine). The port is 5376.
Run the debugger. It will wait for Kodi.
Update Nakamori (obviously)
Enable debugging in Nakamori. Enter the IP of the debugger.
Start debugging.